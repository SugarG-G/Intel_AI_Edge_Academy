gcc iotdb_select.c -o iotdb_select -lmysqlclient
gcc iotdb_insert.c -o iotdb_insert -lmysqlclient
